using Moq;
using POC.Models.DTO;
using POC.Repository;
using POC.Services;
using POC.Services.Contracts;

namespace POCTestSuit
{
    [TestClass]
    public class UserServiceTest
    {
        Mock<IUserRepository> mockUserRepository;
        IUserService userService;

        [TestInitialize]
        public void TestSetup()
        {
            mockUserRepository = new Mock<IUserRepository>();

            userService = new UserService(mockUserRepository.Object);
        }


        [TestMethod]
        public void UserService_Loads_Users_Success()
        {
            //Arrange
            User[] usersDTO = Enumerable.Range(0, 5).Select(i => new User() { Id = i, Name = i.ToString() }).ToArray();

            mockUserRepository.Setup(c => c.GetUsersAsync()).ReturnsAsync(usersDTO);

            //Act
            var result = userService.GetUsers().GetAwaiter().GetResult();

            //Assert
            Assert.AreEqual(5, result?.Length);
        }
    }
}