﻿using POC.Services.Core;

namespace POC.Repository
{
    public abstract class BaseRepository<T, W>
    {
        protected readonly IHttpService<T> httpService;
        protected readonly ILogger<W> logger;
        protected readonly string resource;

        public BaseRepository(IHttpService<T> httpService, ILogger<W> logger, string resource)
        {
            this.httpService = httpService;
            this.logger = logger;
            this.resource = resource;
        }
    }
}
