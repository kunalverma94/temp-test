﻿using POC.Models.DTO;

namespace POC.Repository
{
    public interface IUserRepository
    {
        public Task<User[]?> GetUsersAsync();

        public Task<bool> DeleteUserAsync(int ID);
    }
}
