﻿using POC.Models.DTO;
using POC.Services.Core;

namespace POC.Repository
{
    public class UserRepository : BaseRepository<User, UserRepository>, IUserRepository
    {
        public UserRepository(IHttpService<User> httpService, ILogger<UserRepository> logger) : base(httpService, logger, "users")
        {
        }

        public async Task<User[]?> GetUsersAsync() => await httpService.GetAsync(resource);

        public async Task<bool> DeleteUserAsync(int ID) => await httpService.DeleteAsync($"{resource}/{ID}");
    }
}
