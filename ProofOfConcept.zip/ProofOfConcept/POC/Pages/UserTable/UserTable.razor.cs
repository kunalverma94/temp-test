﻿using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using POC.Models;
using POC.Pages.Shared;
using POC.Services.Contracts;

namespace POC.Pages.UserTable
{
    public partial class UserTable : IDisposable
    {
        private const string _jsRefreshUsersMethodIdentifier = "POCModuleLibrary.refreshUsers";
        private const int _mockLoadingInterval = 10 * 1000;

        private Popup deleteModal;
        private List<User> userList;
        private Status status;
        private string successMessage;

        private DotNetObjectReference<UserTable> _componentReference;

        [Inject] private IUserService _userService { get; set; }
        [Inject] private IJSRuntime jsRuntime { get; set; }

        public UserTable() => _componentReference = DotNetObjectReference.Create(this);

        public void Dispose() => _componentReference?.Dispose();

        [JSInvokable]
        public void OnRefreshUserComplete(string id)
        {
            if (id != null && int.TryParse(id, out int rID))
            {
                userList.Remove(userList.Single(z => z.ID == rID));
                SetSuccessMessage("Data Has been Loaded Successfully");
            }
        }

        protected override async Task OnInitializedAsync() => await LoadNames();

        #region Helper

        private void SetSuccessMessage(string msg)
        {
            successMessage = msg;
            StateHasChanged();
        }

        private async Task LoadNames()
        {
            status = Status.Loading;

            await Task.Delay(1500);

            Models.DTO.User[]? users = await _userService.GetUsers();

            if (users == null)
            {
                status = Status.Error;
            }
            else
            {
                userList = users.Select(z => new User()
                {
                    ID = z.Id,
                    Brand = z.Company?.Name ?? "N/A",
                    Name = z.Name,
                    Code = z.Address?.Zipcode,
                    Price = z.Name?.Length ?? 0 * 10
                }).ToList();

                status = Status.Success;
            }
        }

        private void OpenDeleteUserPopup(int id)
        {
            deleteModal.Configuration = new PopupConfiguration()
            {
                Title = "Delete User",
                ModalBody = typeof(DeleteUserPopupBody),
                ModalBodyParameters = new Dictionary<string, object> { [nameof(DeleteUserPopupBody.User)] = userList.Single(z => z.ID == id) },
            };

            deleteModal.Open();
        }

        private async Task DeletedUser(IDictionary<string, object> modalResult)
        {
            deleteModal.Close();
            User? item = modalResult[nameof(DeleteUserPopupBody.User)] as User;

            string result = await jsRuntime.InvokeAsync<string>(_jsRefreshUsersMethodIdentifier, _componentReference, _mockLoadingInterval, item?.ID.ToString());
            Console.WriteLine(result);
        }

        private enum Status
        {
            None,
            Loading,
            Error,
            Success,
        }

        #endregion
    }
}
