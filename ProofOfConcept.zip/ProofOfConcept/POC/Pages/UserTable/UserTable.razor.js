﻿window.POCModuleLibrary = {
    refreshUsers: function (dotNetObject, interval, id) {

        appLoadingModule.showLoading();
        new Promise((resolve) => { setTimeout(function () { resolve(appLoadingModule.hideLoading()); }, interval) })
            .then(x => dotNetObject.invokeMethodAsync('OnRefreshUserComplete', id));

        return "RefreshUsers::JS Function"
    }, ...window.POCModuleLibrary
}

/// Module Pattern -globalvariable population -accidental overriding -maintainibility -LoadOnDemand -CLeanups.. 
