﻿using Microsoft.AspNetCore.Components;

namespace POC.Pages.Shared
{
    public class PopupConfiguration
    {
        public string Title { get; set; }
        public Type? ModalBody { get; set; }
        public IDictionary<string, object> ModalBodyParameters { get; set; }
    }
    public partial class Popup
    {
        private string ModalDisplay = "none;";
        private string ModalClass = "";
        private bool ShowBackdrop = false;

        public PopupConfiguration Configuration;

        [Parameter] public EventCallback<IDictionary<string, object>> OnConfirm { get; set; }

        public void Open() => UpdateModalState("block;", "Show", true);

        public void Close() => UpdateModalState();

        private void UpdateModalState(string modalDisplay = "none", string modalClass = "", bool showBackdrop = false)
        {
            ModalDisplay = modalDisplay;
            ModalClass = modalClass;
            ShowBackdrop = showBackdrop;
            StateHasChanged();
        }

        private async Task ClickedOkEvent() => await OnConfirm.InvokeAsync(Configuration.ModalBodyParameters);
    }
}
