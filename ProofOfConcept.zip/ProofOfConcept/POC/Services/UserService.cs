﻿using POC.Models.DTO;
using POC.Repository;
using POC.Services.Contracts;

namespace POC.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository) => this._userRepository = userRepository;

        public async Task<User[]?> GetUsers() => await _userRepository.GetUsersAsync();

        public async Task<bool> DeleteUsers(int ID) => await _userRepository.DeleteUserAsync(ID);
    }
}
