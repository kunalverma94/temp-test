﻿using POC.Models.DTO;

namespace POC.Services.Contracts
{
    public interface IUserService
    {
        Task<User[]?> GetUsers();

        Task<bool> DeleteUsers(int ID);
    }
}
