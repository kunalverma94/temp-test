﻿using System.Net.Http.Json;

namespace POC.Services.Core
{
    public class HttpService<T> : IHttpService<T>
    {
        protected HttpClient _httpClient;

        public HttpService(HttpClient httpClient) => _httpClient = httpClient;

        public async Task<bool> DeleteAsync(string url) => (await _httpClient.DeleteAsync(url)).StatusCode == System.Net.HttpStatusCode.NoContent;

        public async Task<T[]?> GetAsync(string url) => await _httpClient.GetFromJsonAsync<T[]>(url);
    }
}
