﻿namespace POC.Services.Core
{
    public interface IHttpService<T>
    {
        Task<T[]?> GetAsync(string url);

        Task<bool> DeleteAsync(string url);
    }
}
