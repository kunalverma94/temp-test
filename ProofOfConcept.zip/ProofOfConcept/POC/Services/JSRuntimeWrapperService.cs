﻿using Microsoft.JSInterop;
using POC.Services.Contracts;
using System.Text.Json;

namespace POC.Services
{
    public interface IJSRuntimeWrapperService
    {
        Task<T> ExecuteJSFunction<T>(string functionName, params object?[]? args);

        Task ExecuteVoidJSFunction(string functionName, params object?[]? args);
    }
    public class JSRuntimeWrapperService : IJSRuntimeWrapperService
    {
        private readonly IJSRuntime _jsRuntime;

        public JSRuntimeWrapperService(IJSRuntime jsRuntime) => this._jsRuntime = jsRuntime;

        public async Task ExecuteVoidJSFunction(string functionName, params object?[]? args)
            => await _jsRuntime.InvokeVoidAsync(functionName, args);

        public async Task<T> ExecuteJSFunction<T>(string functionName, params object?[]? args)
            => JsonSerializer.Deserialize<T>(await _jsRuntime.InvokeAsync<string>(functionName, args));
    }
}
