using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using POC.Models.DTO;
using POC.Repository;
using POC.Services;
using POC.Services.Contracts;
using POC.Services.Core;

namespace POC
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebAssemblyHostBuilder.CreateDefault(args);
            builder.RootComponents.Add<App>("#app");
            builder.RootComponents.Add<HeadOutlet>("head::after");
            builder.Services.AddLogging();

            ConfigureServices(args, builder);

            await builder.Build().RunAsync();
        }

        private static void ConfigureServices(string[] args, WebAssemblyHostBuilder builder)
        {
            //If single Endpoint where all services are hoisted
            builder.Services.AddScoped(z => new HttpClient { BaseAddress = new Uri(args.FirstOrDefault() ?? "https://jsonplaceholder.typicode.com") });
            builder.Services.AddScoped<IHttpService<User>, HttpService<User>>();

            //If  Endpoint varies for services 
            //builder.Services.AddScoped<IHttpService<User>>(z =>
            //new HttpService<User>(new HttpClient { BaseAddress = new Uri(args.FirstOrDefault() ?? "https://jsonplaceholder.typicode.com/users") }));

            builder.Services.AddScoped<IUserRepository, UserRepository>();
            builder.Services.AddScoped<IUserService, UserService>();
        }
    }
}
